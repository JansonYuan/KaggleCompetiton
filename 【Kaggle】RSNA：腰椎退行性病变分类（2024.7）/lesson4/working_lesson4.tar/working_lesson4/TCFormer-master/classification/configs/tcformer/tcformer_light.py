cfg = dict(
    model='tcformer_light',
    drop_path=0.1,
    clip_grad=None,
    output_dir='work_dirs/tcformer_light',
)